<!DOCTYPE html>
<html lang="en">
<head>

	<!-- start: Meta -->
	<meta charset="utf-8">
	<title>Vision</title> 
	<meta name="description" content="GotYa Free Bootstrap Theme"/>
	<meta name="keywords" content="Template, Theme, web, html5, css3, Bootstrap" />
	<meta name="author" content="Łukasz Holeczek from creativeLabs"/>
	<!-- end: Meta -->
	
	<!-- start: Mobile Specific -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!-- end: Mobile Specific -->
	
	<!-- start: Facebook Open Graph -->
	<meta property="og:title" content=""/>
	<meta property="og:description" content=""/>
	<meta property="og:type" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:image" content=""/>
	<!-- end: Facebook Open Graph -->

    <!-- start: CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/bootstrap-responsive.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Sans:400,700">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Serif">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Boogaloo">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Economica:700,400italic">
	<!-- end: CSS -->

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    <style>

   
 

.holder {
	width: 300px;
	margin: 20px;
	float: left;
	overflow: hidden;
}
.topbar {
	/*border: 1px solid white;*/

	-webkit-background-clip: padding-box;
}
.topbar h1 {
	
	text-align: center;
	margin: 0px 0px 0px 0px;
	color: #fff;
	font-size: 26px;
	text-shadow: 1px 1px 0px rgba(0,0,0,0.3);
	letter-spacing: -1px;
}
.inbar {
	/*border: 1px solid white;*/
	box-shadow: inset 0px 0px 1px 1px rgba(255,255,255,0.5), 
				inset 0px -3px 15px -1px rgba(0,0,0,0.2);
    background: #FFF
}
.inbar ul {
	margin: 0;
	padding: 0;
	list-style-type: none;
}
.inbar ul li { 
	margin: 0;
	padding: 0;
	clear: both;
	}
.inbar ul li span {
	float: left;
	padding: 5px 20px 5px 20px;
	/*border-right: 1px solid #eee;
	border-bottom: 1px solid #eee;*/
	font-weight: 800;
	font-size: 30px;
	color: #888;
	background: #fff;
}
.inbar ul li p {
	padding: 17px 0px 16px 70px;
	/*border-right: 1px solid #eee;*/
	border-bottom: 1px solid #ddd;
	margin: 0;
	color: #666;
	font-size: 16px;
	text-shadow: 1px 1px 0 #fff;
	box-shadow: inset 0 0 1px 1px #fff;
}
.inbar ul li:hover p {
	background: rgba(0,0,0,0.02); 
}
.inbar ul li:hover span {
	color: rgba(0,0,0,0.3);
}
/* Colors */

.blue {
background: #ABABAB;
}
    </style>

</head>
<body>
	
	<!--start: Header -->
	<header style="height:70px">
		
		<!--start: Container -->
		<div class="container">
			
			<!--start: Row -->
			<div class="row">
					
				<!--start: Logo -->
				<div class="logo span3">
						
					<a class="brand" href="#"><img src="img/logo.png" style="width: 170px;height: 70px;margin-top: 3px;"></a>
					
					
						
				</div>
				<!--end: Logo -->
					
				<!--start: Navigation -->
				<div class="span9">
					
					<div class="navbar navbar-inverse">
			    		<div class="navbar-inner">
			          		<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
			            		<span class="icon-bar"></span>
			            		<span class="icon-bar"></span>
			            		<span class="icon-bar"></span>
			          		</a>
			          		<div class="nav-collapse collapse">
			            		<ul class="nav">
			              			<li class="active"><a href="index.html">Home</a></li>
			              			<li><a href="About.html">About</a></li>
									<li><a href="Gallery.html">Gallery</a></li>
									<li><a href="Events.html">Events</a></li>
			              			<li><a href="Contact.html">Contact Us</a></li>
			         <!--     			<li class="dropdown">
			                			<a href="#" class="dropdown-toggle" data-toggle="dropdown">Dropdown <b class="caret"></b></a>
			                			<ul class="dropdown-menu">
			                  				<li><a href="#">Action</a></li>
			                  				<li><a href="#">Another action</a></li>
			                  				<li><a href="#">Something else here</a></li>
			                  				<li class="divider"></li>
			                  				<li class="nav-header">Nav header</li>
			                  				<li><a href="#">Separated link</a></li>
			                  				<li><a href="#">One more separated link</a></li>
			                			</ul>
			              			</li> -->
			            		</ul>
			          		</div>
			        	</div>
			      	</div>
					
				</div>	
				<!--end: Navigation -->
					
			</div>
			<!--end: Row -->
			
		
		<!--end: Container-->			
			
        </div></header>
	<!--end: Header-->
	<div class="baap">
		<!-- start: Slider -->
		<div class="slider-wrapper">

			<div id="da-slider" class="da-slider">
				<div class="da-slide">
					<h2>Noesis 2K16</h2>
					<p>Annual Mega Fest of Vision. This Year had more than 1400 participants across the city.</p>
					<a href="#" class="da-link">Read more</a>
					<div class="da-img"><img src="img/parallax-slider/NOesis.png" alt="image01" /></div>
				</div>
				<div class="da-slide">
					<h2>White Line Tracer Workshop</h2>
					<p>Annually Conducted Workshop by Vision. </p>
					<a href="#" class="da-link">Read more</a>
					<div class="da-img"><img src="img/parallax-slider/WLT.png" alt="image02" /></div>
				</div>
				<div class="da-slide">
					<h2>Robo Fifa</h2>
					<p>Annual Event Conducted in Technosearch Every year.</p>
					<a href="#" class="da-link">Read more</a>
					<div class="da-img"><img src="img/parallax-slider/RoboFifa.png" alt="image03" /></div>
				</div>
				<div class="da-slide">
					<h2>Circuit Run</h2>
					<p>Annual Event Conducted in Technosearch.</p>
					<a href="#" class="da-link">Read more</a>
					<div class="da-img"><img src="img/parallax-slider/circuit_run.png" alt="image04" /></div>
				</div>
				<div class="da-slide">
					<h2>Code Kriegers</h2>
					<p>Annual Event conducted in Technosearch Every Year.</p>
					<a href="#" class="da-link">Read more</a>
					<div class="da-img"><img src="img/parallax-slider/CK.png" alt="image05" /></div>
				</div>
				<nav class="da-arrows">
					<span class="da-arrows-prev"></span>
					<span class="da-arrows-next"></span>
				</nav>
			</div>
			
		</div>
		<!-- end: Slider -->
				
		<!--start: Wrapper-->
		<div id="wrapper">
					
			<!--start: Container -->
			
				
				
				
				<!-- start: Row -->
				<div class="row" style="padding-top: 30px">
					
						
						<!-- start: Icon Box Start -->
						
					<link href='http://fonts.googleapis.com/css?family=Arimo' rel='stylesheet' type='text/css'>

	<div class="holder" style="float:left;">
		<div class="topbar blue">
			<h1>News and Events</h1>
		</div>
		<div class="inbar">
			<ul>
				<li> <p>Lorem ipsum dolor</p></li>
				<li><p> At vero eos et</p></li>
				<li> <p> At vero eos et accusam</p></li>
				<li><p>Lorem ipsum dolor sit amet</p></li>
			</ul>
			<div style="clear:both"></div>
		</div>
	</div>	
<div class="span6">
    <div class="avatar view-team">
        <img src="eImg/2011/12.jpg" alt="circuit run">
        <div class="mask body-collapsible-pe">
        <div class="body carousel-pe">
            <h2>Swarm Robotics</h2>
            <p>2K11</p>
            
            </div>
        </div>
    </div>
                    </div>
			<div class="span6" style="float:right">
                    <!-- start: Follow Us -->
					<h2 style="text-align:center">Follow Us!</h2>
					<ul class="social-grid">
						<li>
							<div class="social-item">				
								<div class="social-info-wrap">
									<div class="social-info">
										<div class="social-info-front social-twitter">
											<a href="http://twitter.com"></a>
										</div>
										<div class="social-info-back social-twitter-hover">
											<a href="http://twitter.com"></a>
										</div>	
									</div>
								</div>
							</div>
						</li>
                        <li>
							<div class="social-item">				
								<div class="social-info-wrap">
									<div class="social-info">
										<div class="social-info-front social-twitter">
											<a href="http://twitter.com"></a>
										</div>
										<div class="social-info-back social-twitter-hover">
											<a href="http://twitter.com"></a>
										</div>	
									</div>
								</div>
							</div>
						</li>
                        <li>
							<div class="social-item">				
								<div class="social-info-wrap">
									<div class="social-info">
										<div class="social-info-front social-twitter">
											<a href="http://twitter.com"></a>
										</div>
										<div class="social-info-back social-twitter-hover">
											<a href="http://twitter.com"></a>
										</div>	
									</div>
								</div>
							</div>
						</li>
                         
						<li>
							<div class="social-item">				
								<div class="social-info-wrap">
									<div class="social-info">
										<div class="social-info-front social-facebook">
											<a href="http://facebook.com"></a>
										</div>
										<div class="social-info-back social-facebook-hover">
											<a href="http://facebook.com"></a>
										</div>
									</div>
								</div>
							</div>
						</li>
						<li>
							<div class="social-item">				
								<div class="social-info-wrap">
									<div class="social-info">
										<div class="social-info-front social-dribbble">
											<a href="http://dribbble.com"></a>
										</div>
										<div class="social-info-back social-dribbble-hover">
											<a href="http://dribbble.com"></a>
										</div>	
									</div>
								</div>
							</div>
						</li>
						<li>
							<div class="social-item">				
								<div class="social-info-wrap">
									<div class="social-info">
										<div class="social-info-front social-flickr">
											<a href="http://flickr.com"></a>
										</div>
										<div class="social-info-back social-flickr-hover">
											<a href="http://flickr.com"></a>
										</div>	
									</div>
								</div>
							</div>
						</li>
                        <li>
                            <div class="social-item">				
								<div class="social-info-wrap">
									<div class="social-info">
										<div class="social-info-front social-youtube">
											<a href="http://twitter.com"></a>
										</div>
										<div class="social-info-back social-youtube-hover">
											<a href="http://twitter.com"></a>
										</div>	
									</div>
								</div>
							</div>

                        </li>
                        <li>
                            <div class="social-item">				
								<div class="social-info-wrap">
									<div class="social-info">
										<div class="social-info-front social-blogger">
											<a href="http://twitter.com"></a>
										</div>
										<div class="social-info-back social-blogger-hover">
											<a href="http://twitter.com"></a>
										</div>	
									</div>
								</div>
							</div>

                        </li>
					</ul>
					<!-- end: Follow Us -->
				
					<!-- start: Newsletter -->
					<form id="newsletter">
						<h3>Newsletter</h3>
						<p>Please leave us your email</p>
						<label for="newsletter_input">@:</label>
						<input type="text" id="newsletter_input">
						<input type="submit" id="newsletter_submit" value="submit">
					</form>
					<!-- end: Newsletter -->
                    </div>			
							
								
            </div>		
								
								
				
								
								
					
					
					<!-- end: Icon Boxes -->
					<div class="clear"></div>
				</div>
				<!-- end: Row -->
				
				
				
			
			<!--end: Container-->
		
		</div>
		<!-- end: Wrapper  -->			
	
<!-- start: Java Script -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="js/jquery-1.8.2.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/flexslider.js"></script>
<script src="js/carousel.js"></script>
<script src="js/jquery.cslider.js"></script>
<script src="js/slider.js"></script>
<script defer="defer" src="js/custom.js"></script>
<!-- end: Java Script -->

</body>
</html>