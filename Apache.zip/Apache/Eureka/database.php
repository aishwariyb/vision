<?php
	$db = new mysqli('localhost','root','','vision') or die("Could not Connect My Sql");
?>
