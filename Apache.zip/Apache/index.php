<!DOCTYPE html>
<html>
    <head>
        <!-- start: Mobile Specific -->
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <!-- end: Mobile Specific -->
        <style>
        #video{ position: relative; }
        #a1{  position: absolute; bottom: 10%; right: 10%;
            color:blue;
            border: 5px solid #4db6ac; display: block; background: #FFF; 
            border-radius:30px;
            z-index: 2147483647;
        } 
        </style>
        <link href="css/bootstrap.css" rel="stylesheet">
		<link href="css/bootstrap-responsive.css" rel="stylesheet">
		

    </head>
    
    <body style="width:100%;margin-left:0px;padding:0px">
        
        <div id="video" class="hidden-phone hidden-tablet">
            <video id="video-background"  preload="auto" autoplay="true" loop="loop" muted="muted" volume="0" width="80%" style="margin-left:10%">
                <source src="StartPage/Vision.mp4" type="video/mp4">
              </video><br/>
            <a id="a1" href="home.php" ><button  style="color:#4db6ac;border:none;font-variant:small-caps;font-size:20px;padding:25px;background-color:RGBA(0,0,0,0)">Start Here!</button></a>
        </div>
        
        <div id="video" class="hidden-desktop" >
            <video id="video-background" preload="auto" autoplay="true" loop="loop" muted="muted" volume="0" width="100%" height="100%" style="">
                <source src="StartPage/Comp.mp4" type="video/mp4">
              </video><br/>
            <div >
            <a href="home.php" style="border: 5px solid #4db6ac;  background: #FFF; 
            border-radius:30px;float:right;margin-right:27%;"><button  style="color:#4db6ac;border:none;font-variant:small-caps;font-size:20px;padding:25px;background-color:RGBA(0,0,0,0)">Start Here!</button></a>
            </div>
        </div>
        
        
        
         <script src="js/jquery-1.8.2.js"></script>
        <script src="js/bootstrap.js"></script>
        <script src="js/flexslider.js"></script>
        <script src="js/carousel.js"></script>
        <script src="js/jquery.cslider.js"></script>
        <script src="js/slider.js"></script>
        <script defer="defer" src="js/custom.js"></script>
    </body>
</html>